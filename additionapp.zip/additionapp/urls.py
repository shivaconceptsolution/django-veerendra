from django.urls import path
from . import views

urlpatterns = [

path('',views.index,name='index'),
path('addlogic',views.addlogic,name='addlogic'),
path('fact',views.fact,name='fact'),
path('factlogic',views.factlogic,name='factlogic'),
path('prime',views.prime,name='prime'),
path('primelogic',views.primelogic,name='primelogic'),
path('fibo',views.fibo,name='fibo'),
path('fibologic',views.fibologic,name='fibologic')

]