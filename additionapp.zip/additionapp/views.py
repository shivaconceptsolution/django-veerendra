from django.shortcuts import render
from django.http import HttpResponse

def index(request):
  return render(request,"additionapp/index.html")


def addlogic(request):
   a = request.POST["txtnum1"]
   b = request.POST["txtnum2"]
   c = int(a)+int(b)
   return HttpResponse("result is "+str(c))

